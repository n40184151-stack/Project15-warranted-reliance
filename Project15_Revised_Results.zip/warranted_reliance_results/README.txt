Project 15 warranted reliance experiments.
Twelve primary figures and twelve primary tables; supporting audits and predictions included.
PDF figures are vector output; PNG figures are 300 dpi; tables have CSV and PDF copies.
See metadata/captions.md for scope and assumptions. Costs and reviewer performance are scenarios.
No human trust study or real-world deployment evaluation is claimed.
UCI source: https://doi.org/10.24432/C55S3H (CC BY 4.0); Census PUMS releases via Census.gov.
ACS task definition follows Folktables; sex, race and relationship predictors omitted.
