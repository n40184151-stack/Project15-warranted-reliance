**S01_dataset_audit** Raw, eligible and sampled record counts. ACS uses the canonical ACSIncome filter; primary model excludes sex/race.

**S02_source_provenance** Authoritative releases and exact-byte SHA256 hashes.

**S06_feature_audit** Predictor roles, missingness and ranges before training. Historical UCI sentinel codes are retained as recorded. ACS sex, race and relationship fields are excluded; income and identifiers never enter predictors.

**S03_split_audit** Disjoint group-aware partitions; group constraints make percentages approximate.

**S04_model_diagnostics** Both baselines, raw and recalibrated; selection uses validation Brier score only. Test diagnostics are reporting, not tuning.

**RQ1_F1_reliability** Fixed-bin held-out reliability. Bin counts in companion CSV; no claim of individual probability certainty.

**RQ1_F2_stakes_map** Positive values favor cost-aware abstention. Costs are scenarios; finite-test differences need not favor either method.

**RQ1_T1_policy_comparison** Primary scenario FN=5, FP=1, idealized total defer cost=.15. Delta <0 favors the row policy over confidence abstention; paired cluster-bootstrap 95% intervals.

**S05_split_seed_sensitivity** All split seeds and supporting baselines; not independent replications of a population study.

**RQ1_T2_same_confidence_reversals** Same cases and probabilities; FN cost changes from 1 to 5, FP=1, ideal defer=.30. This is a constructed decision contrast, not a causal effect on human reliance.

**RQ2_F3_subgroup_reliability** Recorded-sex calibration; plotted bins require >=20 records. Full bin counts are exported. Group evidence is not a fairness verdict.

**RQ2_F4_error_coverage** Descriptive shared-threshold paths; errors with fewer than 50 automated cases are suppressed. Thresholds are not chosen on these test curves.

**RQ2_T3_subgroup_evidence** Primary shared confidence policy. Recorded categories retain source meanings. Adequate counts is an operational screen, not proof of reliability; ECE is descriptive and bin-dependent.

**RQ2_T4_group_informed_thresholds** Sex-specific validation thresholds, prespecified shrinkage n/(n+200), fallback to shared threshold below 80 validation records. This is a diagnostic comparison, not a deployment recommendation.

**RQ3_T5_transport_audit** ACS source DE 2018; targets MD 2018 and DE 2019. Same source-selected model and confidence threshold. Target sigmoid fit uses separate households; loss intervals condition on fitted calibration.

**RQ3_F5_natural_shift** Natural geographic and year-domain comparisons with paired-within-domain recalibration design. Between-domain differences are descriptive, not causal effects of state or year.

**RQ3_F6_constructed_mix** Synthetic UCI age-mixture reweighting of the same test sample. No claim of observed drift, causal age effects or new deployment data.

**RQ3_T6_recalibration_sample_size** Five nested household-order samples per target. SD describes recalibration-sample sensitivity, not a confidence interval. All rows use the same independent target test set.

**RQ4_F7_fallback_map** Positive values favor fallback-aware review. Fallback performance and costs are constructed assumptions; losses integrate fallback error analytically.

**RQ4_F8_fallback_sensitivity** Review cost=.05. Confidence threshold comes from the idealized primary scenario and stays fixed, exposing its transport to an imperfect fallback. Fallback-aware decisions use the stated scenario.

**RQ4_T7_imperfect_fallback** Primary assumed reviewer error=.10, review cost=.05, FN=5, FP=1. Intervals do not incorporate uncertainty about assumed reviewer error. These are expected scenario losses, not observed human outcomes.

**RQ4_T8_review_capacity** Fixed batch review capacity; excess referrals receive cost-sensitive automation. Review demand is model/scenario-derived, not measured institutional workload. Intervals condition on the fitted scores and allocation.

**UQ_T1_interval_policy_audit** Revised RQ2. Fixed LR; independent sigmoid-fitting and reliability-evidence partitions. Delta=interval minus point loss. Paired cluster-bootstrap 95% intervals condition on fitted evidence and model. Five-bin conservative intervals are used for bin-average risk, not individual probabilities.

**UQ_T2_evidence_size_sensitivity** Revised RQ2. Five nested cluster-order samples per evidence size and nine cost scenarios. SD is subsampling sensitivity, not a confidence interval. All configurations share an independent test set; exploratory design.

**UQ_F1_evidence_size_loss_coverage** Revised RQ2. FN=5, FP=1, idealized total deferral cost=.15. Lines average five evidence-order repetitions; no independent repeated-test claim.

**UQ_F2_interval_action_changes** Revised RQ2. Same fixed-LR predictions and independent bin evidence; action changes arise from point versus interval loss evaluation. Conservative bounds can make deferral dominate.

**GB_T1_group_capacity_audit** Revised RQ4. Recorded-sex outcomes under shared capacity; assumed fallback error=.10 and review cost=.05. Deferral burden is operationalized as requests, actual review and unmet referrals, not observed delay or harm. Full age/race and fallback-error scenarios in data/GB_all_group_capacity_scenarios.csv.

**GB_T2_sex_gap_audit** Revised RQ4. Female minus male differences; signed gaps are not fairness verdicts. Joint cluster-bootstrap intervals for loss gaps condition on fitted scores, fixed batch allocation and assumed reviewer performance. The same reviewer error is assumed across groups.

**GB_F1_group_review_capacity** Revised RQ4. A group review rate can exceed the overall capacity fraction because slots are allocated over the complete batch, not equally within each group. Assumed fallback error=.10; no measured human behavior.

**GB_F2_group_system_loss** Revised RQ4. Group expected system loss includes assumed fallback errors and review cost. Lines are descriptive; group CIs are in GB_T1. Differences do not establish discrimination or causal effects.